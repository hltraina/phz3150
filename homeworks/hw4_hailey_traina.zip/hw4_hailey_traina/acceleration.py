def acceleration(u1,u2,t1,t2):
    speed = u2-u1
    time = t2-t1
    acc = speed/time
    return acc
