def print_twice(bruce):
    print(bruce)
    print(bruce)
    print( cat )
    
def cat_twice(part1, part2):
    cat = part1 + part2
    print_twice(cat)